# Copyright (c) 2023, Tech Ventures and Contributors
# See license.txt

# import frappe
from frappe.tests.utils import FrappeTestCase


class TestSizingProgram(FrappeTestCase):
	pass
